export class Restaurant {
    rest_id:number;
    rest_name:string;
    rest_address:string;
    phone:string;
    open_time:string;
	close_time:string;
    active:boolean;
    constructor()
    {
    }
    /* constructor( restid:number,
        rest_name:string,
        rest_address:string,
        phone:string,
        open_time:string,
        close_time:string,
        active:boolean)
        {
            this.rest_id=rest_id;
            this.rest_name=rest_name;
            this.rest_address=rest_address;
            this.phone=phone;
            this.open_time=open_time;
            this.close_time=close_time;
            this.active=active;
        } */
}
