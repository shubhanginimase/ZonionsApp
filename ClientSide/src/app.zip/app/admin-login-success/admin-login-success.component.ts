import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-login-success',
  templateUrl: './admin-login-success.component.html',
  styleUrls: ['./admin-login-success.component.css']
})
export class AdminLoginSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
